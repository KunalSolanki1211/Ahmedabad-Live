package com.meri.aavaz;

import android.graphics.drawable.Drawable;

public class AdminDashboardModel {

    private int id;
    private String title;
    private int image;

    public AdminDashboardModel(int id, String title, int image) {
        this.id = id;
        this.title = title;
        this.image = image;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return this.image;
    }

    public void setImage(int image) {
        this.image = image;
    }

}

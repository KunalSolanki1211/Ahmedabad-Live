package com.meri.aavaz.utils;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class SendMail extends AsyncTask<String, String, String> {
    Context context;
    Properties pro;
    Session session;
    MimeMessage mMsg;
    String ToEmail, Tosubject, Tomessage;

    public SendMail(Context context, String s_signup_email, String subject, String message) {
        this.context = context;
        this.ToEmail = s_signup_email;
        this.Tosubject = subject;
        this.Tomessage = message;
    }

    @Override
    protected String doInBackground(String... strings) {
        pro = new Properties();
        pro.put("mail.smtp.host", "smtp.gmail.com");
        pro.put("mail.smtp.port", "465");
        pro.put("mail.smtp.ssl.enable", "true");
        pro.put("mail.smtp.auth", "true");
//        pro.put(Constant.Smtphostkey, Constant.SmatphostValue);
//        pro.put(Constant.Sslsocketportkey, Constant.SslsocketportValue);
//        pro.put(Constant.Sslclassfactorykey, Constant.SslclassfactoryValue);
//        pro.put(Constant.Sslauthnticationkey, Constant.SslauthnticationValue);
//        pro.put(Constant.Sslsmtpportkey, Constant.SslsmtpportValue);
        session = Session.getDefaultInstance(pro, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
//                return new PasswordAuthentication(Constant.ADMINEmail, Constant.ADMINPassword);
//                return new PasswordAuthentication("ahemdabadliveapp@gmail.com", "Live9876");
                return new PasswordAuthentication("ahemdabadliveapp@gmail.com", "qvwtfkmuccumexvx");
            }
        });
        try {
            mMsg = new MimeMessage(session);
//            mMsg.setFrom(new InternetAddress(Constant.ADMINEmail));
            mMsg.addRecipient(Message.RecipientType.TO, new InternetAddress(ToEmail));
            mMsg.setSubject(Tosubject);
            mMsg.setText(Tomessage);
            Transport.send(mMsg);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        Toast.makeText(context, "Email sent", Toast.LENGTH_SHORT).show();
        super.onPostExecute(s);
    }
}

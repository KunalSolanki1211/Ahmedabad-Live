package com.meri.aavaz.easyimage;

import androidx.core.content.FileProvider;

public class ExtendedFileProvider extends FileProvider {

}
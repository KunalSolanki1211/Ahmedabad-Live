package com.meri.aavaz;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

/** @noinspection ALL*/
public class DepartmentsListActivity extends AppCompatActivity {
    private ArrayList<String> departments;
    ListView listView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_departments_list);
        if (new ConnectionDetector(this).isConnectingToInternet()) {
            new getType().execute();
        } else {
            new ConnectionDetector(this).connectiondetect();
        }
        listView = findViewById(R.id.listView);
        button = findViewById(R.id.addDepartmentBtn);

        button.setOnClickListener(view -> {
            startActivity(new Intent(this, AddDepartmentActivity.class));
        });
    }

    private class getType extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(DepartmentsListActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "type");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    departments = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        departments.add(jsonObject.getString("type"));
                    }
                    ArrayAdapter<String> listViewAdapter = new ArrayAdapter<>(
                            DepartmentsListActivity.this,
                            R.layout.support_simple_spinner_dropdown_item,
                            departments
                    );
                    listView.setAdapter(listViewAdapter);
                } else {
                    Toast.makeText(DepartmentsListActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
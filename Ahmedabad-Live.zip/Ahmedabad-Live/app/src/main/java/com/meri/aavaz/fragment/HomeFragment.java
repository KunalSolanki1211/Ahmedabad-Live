package com.meri.aavaz.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;

import com.meri.aavaz.ContactUsFragment;
import com.meri.aavaz.HomeActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.adapter.HomeAdapter;
import com.meri.aavaz.model.HomeModel;
import com.meri.aavaz.model.ReqRegisterModel;
import com.meri.aavaz.utils.ConstantSp;

public class HomeFragment extends Fragment implements HomeAdapter.OnItemClickListener {

    SharedPreferences sp;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((HomeActivity) getActivity()).setTitle(getString(R.string.home));
        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        final TextView tvUserName = view.findViewById(R.id.fragment_home_tv_user_name);
        final RecyclerView rvHome = view.findViewById(R.id.fragment_home_rv);
        final GridLayoutManager gm = new GridLayoutManager(getActivity(), 1);
        rvHome.setLayoutManager(gm);
        final ArrayList<HomeModel> homeList = new ArrayList<>();
        homeList.add(new HomeModel(0, getString(R.string.add_complaint), R.drawable.logo_add_complaint));
        homeList.add(new HomeModel(1, getString(R.string.view_profile), R.drawable.logo_view_profile));
        homeList.add(new HomeModel(2, getString(R.string.view_complaint), R.drawable.logo_complaint));
        homeList.add(new HomeModel(3, getString(R.string.contact_us), R.drawable.logo_contact_us));
        homeList.add(new HomeModel(4, getString(R.string.about_us), R.drawable.logo_about_us));
//        homeList.add(new HomeModel(5, getString(R.string.government_departments)));
        final HomeAdapter homeAdapter = new HomeAdapter();
        homeAdapter.setOnItemClickListener(this);
        homeAdapter.addAll(homeList);
        rvHome.setAdapter(homeAdapter);

        tvUserName.setText(String.format("Hello, %s %s", sp.getString(ConstantSp.FNAME, ""), sp.getString(ConstantSp.LNAME, "")));

        final ReqRegisterModel reqRegisterModel = ((HomeActivity) getActivity()).getReqRegisterModel();
        if (reqRegisterModel != null) {
            //tvUserName.setText(reqRegisterModel.getFirstName());

        }

    }

    @Override
    public void onItemClickListener(int position) {
        NavHostFragment navHostFragment = (NavHostFragment) requireActivity().getSupportFragmentManager().findFragmentById(R.id.navHostFragment);
        assert navHostFragment != null;
        NavController navController = navHostFragment.getNavController();
        switch (position) {
            case 0:
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    ((HomeActivity) Objects.requireNonNull(getActivity())).replaceFragment(new AddComplaintFragment());
//                }
                navController.navigate(HomeFragmentDirections.actionMenuDrawerHomeToMenuDrawerAddComplaint());
                break;
            case 1:
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    ((HomeActivity) Objects.requireNonNull(getActivity())).replaceFragment(new ProfileFragment());
//                }
                navController.navigate(HomeFragmentDirections.actionMenuDrawerHomeToMenuDrawerProfile());
                break;
            case 2:
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    ((HomeActivity) Objects.requireNonNull(getActivity())).replaceFragment(new ComplaintListFragment());
//                }
                navController.navigate(HomeFragmentDirections.actionMenuDrawerHomeToMenuDrawerViewComplaints());
                break;
            case 3:
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    ((HomeActivity) Objects.requireNonNull(getActivity())).replaceFragment(new AboutUsFragment());
//                }
                navController.navigate(HomeFragmentDirections.actionMenuDrawerHomeToMenuDrawerContactUs());
                break;
            case 4:
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    ((HomeActivity) Objects.requireNonNull(getActivity())).replaceFragment(new ContactUsFragment());
//                }
                navController.navigate(HomeFragmentDirections.actionMenuDrawerHomeToMenuDrawerAboutUs());
                break;
        }
    }
}

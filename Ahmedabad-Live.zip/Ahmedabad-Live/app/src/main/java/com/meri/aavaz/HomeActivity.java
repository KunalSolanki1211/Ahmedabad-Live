package com.meri.aavaz;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import com.meri.aavaz.easyimage.EasyImage;
import com.meri.aavaz.fragment.AboutUsFragment;
import com.meri.aavaz.fragment.AddComplaintFragment;
import com.meri.aavaz.fragment.ComplaintListFragment;
import com.meri.aavaz.fragment.HomeFragment;
import com.meri.aavaz.fragment.ProfileFragment;
import com.meri.aavaz.model.ReqRegisterModel;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.Constants;
import com.meri.aavaz.utils.PermissionUtils;
import com.meri.aavaz.utils.ProgressUtils;
import com.meri.aavaz.utils.SendMail;


// phone number - +44 7488855203
public class HomeActivity extends AppCompatActivity {
    private DrawerLayout drawer;

    private ReqRegisterModel reqRegisterModel;
    private PermissionUtils permissionUtils;
    SharedPreferences sp;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
//        new SendMail(
//                this,
//                "1tnaesiu3f@waterisgone.com",
//                "Test",
//                "Test"
//        )
//                .execute();
        sp = getSharedPreferences(ConstantSp.PREF,MODE_PRIVATE);
        permissionUtils = new PermissionUtils(this);
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.getMenu().findItem(R.id.menu_drawer_logout).setOnMenuItemClickListener(menuItem -> {
            sp.edit().clear().commit();
            Intent intent1 = new Intent(this, AuthorizationActivity.class);
            startActivity(intent1);
            finish();
            return true;
        });

        if (getIntent() != null && getIntent().getExtras() != null) {
            reqRegisterModel = getIntent().getParcelableExtra(Constants.KEY_USER_DATA);
        }
        permissionUtils
                .checkPermission(PermissionUtils.PERMISSION_STORAGE, 101);
        EasyImage.configuration(this)
                .setImagesFolderName(getString(R.string.app_name))
                .setCopyTakenPhotosToPublicGalleryAppFolder(true)
                .setCopyPickedImagesToPublicGalleryAppFolder(true)
                .setAllowMultiplePickInGallery(false);

        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.navHostFragment);
        assert navHostFragment != null;
        NavController navController = navHostFragment.getNavController();
        NavigationUI.setupActionBarWithNavController(this, navController, drawer);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.navHostFragment);
        return NavigationUI.navigateUp(navController, drawer);
    }

    public void replaceFragment(final Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment, fragment.getClass().getSimpleName())
                .addToBackStack("")
                .commit();
    }

    public void addFragment(final Fragment nextFragment, final Fragment currentFragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container, nextFragment, nextFragment.getClass().getSimpleName())
                .hide(currentFragment)
                .addToBackStack(nextFragment.getClass().getSimpleName())
                .commit();
    }


    public void showProgressDialog() {
        ProgressUtils.getInstance(this).show();
    }

    public void hideProgressDialog() {
        ProgressUtils.getInstance(this).close();
    }

    public ReqRegisterModel getReqRegisterModel() {
        return reqRegisterModel;
    }

    public void setTitle(final String title) {
        getSupportActionBar().setTitle(title);
    }

    @Override
    protected void onDestroy() {
        // Clear any configuration that was done!
        EasyImage.clearConfiguration(this);
        super.onDestroy();
    }

    public PermissionUtils getPermissionUtils() {
        if (permissionUtils == null) {
            permissionUtils = new PermissionUtils(this);
        }
        return permissionUtils;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        permissionUtils.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        final Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.container);
        if (fragment instanceof AddComplaintFragment) {
            fragment.onActivityResult(requestCode, resultCode, data);
        }
    }

}

package com.meri.aavaz.utils;

public class ConstantSp {
    public static final String BASE_URL = "https://ahmedabadliveapp.000webhostapp.com/PublicService/";
    public static final String PREF = "pref";
    public static final String ID = "id";
    public static final String FNAME = "fname";
    public static final String LNAME = "lname";
    public static final String CNO = "cno";
    public static final String EMAIL = "email";
    public static final String PASSWORD = "password";
    public static final String ADDRESS = "address";
    public static final String AREA = "area";
    public static final String WORDNO = "wordno";
    public static final String ADHAR = "adhar";
    public static final String TYPE = "type";
    public static final String COMPLAIN_ID = "complain_id";
    public static final String COMPLAIN_NAME = "complain_name";
    public static final String COMPLAIN_DESC = "complain_desc";
    public static final String COMPLAIN_TYPE = "complain_type";
    public static final String COMPLAIN_OCCUPATION = "complain_occupation";
    public static final String COMPLAIN_URL = "complain_url";
    public static final String COMPLAIN_ADDRESS = "complain_address";
    public static final String COMPLAIN_STATUS = "complain_status";

}

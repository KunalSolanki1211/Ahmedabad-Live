package com.meri.aavaz;

/**
 * Created by admin on 5/19/2018.
 */

public abstract class Test  {


    public void init(){

    }

}

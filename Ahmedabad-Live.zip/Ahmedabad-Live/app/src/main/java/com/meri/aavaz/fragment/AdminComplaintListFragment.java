package com.meri.aavaz.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import com.meri.aavaz.R;
import com.meri.aavaz.adapter.ComplaintListAdapter;
import com.meri.aavaz.model.ReqAddComplaintModel;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

/**
 * Created by mavyasoni on 28/02/18.
 */

public class AdminComplaintListFragment extends Fragment {

    SharedPreferences sp;
    ComplaintListAdapter adapter;
    RecyclerView rvComplaintList;
    ArrayList<ReqAddComplaintModel> reqAddComplaintModels;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_complaint_list, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sp = requireActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        rvComplaintList = view.findViewById(R.id.fragment_complaint_list_rv);
        final LinearLayoutManager lm = new LinearLayoutManager(getActivity());
        rvComplaintList.setLayoutManager(lm);

        /*final ComplaintListAdapter adapter = new ComplaintListAdapter(getActivity());
        adapter.addAll(new ArrayList<ReqAddComplaintModel>());
        rvComplaintList.setAdapter(adapter);
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference(Constants.TABLE_COMPLAINT);
        ref.child(user.getUid()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                final ReqAddComplaintModel reqAddComplaintModel = dataSnapshot.getValue(ReqAddComplaintModel.class);
                adapter.add(reqAddComplaintModel);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                final ReqAddComplaintModel reqAddComplaintModel = dataSnapshot.getValue(ReqAddComplaintModel.class);
                adapter.remove(reqAddComplaintModel);
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }
    }

    private class getData extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setCancelable(false);
            pd.setMessage("Please Wait...");
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getUserComplain");
                hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            } else if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getAdminComplain");
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            } else {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getTypeComplain");
                hashMap.put("complainType",sp.getString(ConstantSp.TYPE,""));
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    reqAddComplaintModels = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        ReqAddComplaintModel list = new ReqAddComplaintModel();
                        list.setComplainerId(jsonObject.getString("id"));
                        list.setComplainerName(jsonObject.getString("complainName"));
                        list.setComplaintType(jsonObject.getString("complainType"));
                        list.setOccupation(jsonObject.getString("occupation"));
                        list.setDescription(jsonObject.getString("desc"));
                        list.setDocumentUrl(jsonObject.getString("image"));
                        list.setReceiveStatus(jsonObject.getString("receiveStatus"));
                        list.setAddress(jsonObject.getString("address"));
                        reqAddComplaintModels.add(list);
                    }
                    adapter = new ComplaintListAdapter(getActivity(),reqAddComplaintModels);
                    rvComplaintList.setAdapter(adapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}

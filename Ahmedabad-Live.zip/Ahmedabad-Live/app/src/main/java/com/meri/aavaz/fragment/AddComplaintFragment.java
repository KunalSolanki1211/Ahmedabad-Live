package com.meri.aavaz.fragment;

import static android.app.Activity.RESULT_OK;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import net.gotev.uploadservice.MultipartUploadRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.meri.aavaz.HomeActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.easyimage.DefaultCallback;
import com.meri.aavaz.easyimage.EasyImage;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.GPSTracker;
import com.meri.aavaz.utils.MakeServiceCall;
import com.meri.aavaz.utils.PermissionUtils;

public class AddComplaintFragment extends Fragment implements PermissionUtils.PermissionGranted {
    /*private FirebaseStorage storage;
    private StorageReference storageReference;
    private FirebaseAuth mAuth;*/

    private List<File> documentList;

    private EditText edtComplainerName,address;
    private Spinner spOccupation;
    private Spinner spComplaintType;
    private EditText edtDescription;
    ArrayList<String> strings;
    private int PICK_IMAGE_REQUEST = 1;
    private static final int STORAGE_PERMISSION_CODE = 123;
    ProgressDialog pd;
    private Bitmap bitmap;
    private Uri filePath;
    Cursor c = null;
    String sComplainType;
    SharedPreferences sp;

    String[] appPermission = {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION};
    int PERMISSION_CODE =1;

    String sAddress,sCity,sState,sCountry,sPostcode;
    private static final int CAMERA_REQUEST = 1888;
    private static final int MY_CAMERA_PERMISSION_CODE = 200;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_complaint, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((HomeActivity) getActivity()).setTitle(getString(R.string.add_complaint));
        final Button btnSubmit = view.findViewById(R.id.fragment_add_complaint_btn_submit);
        edtComplainerName = view.findViewById(R.id.fragment_add_complaint_edt_name);
        spOccupation = view.findViewById(R.id.fragment_add_complaint_sp_occupation);
        spComplaintType = view.findViewById(R.id.fragment_add_complaint_sp_type);
        edtDescription = view.findViewById(R.id.fragment_add_complaint_edt_description);
        address = view.findViewById(R.id.fragment_add_complaint_edt_address);
        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getType().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        spComplaintType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sComplainType = (String) adapterView.getItemAtPosition(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        /*storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        mAuth = FirebaseAuth.getInstance();
        ((HomeActivity) getActivity())
                .getPermissionUtils().setPermissionGranted(this);*/
        final TextView tvAttachment = view.findViewById(R.id.fragment_add_complaint_tv_photo);
        tvAttachment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*if (!((HomeActivity) getActivity())
                        .getPermissionUtils().checkPermission(PermissionUtils.PERMISSION_STORAGE, 101)) {
                    EasyImage.openChooserWithGallery(getActivity(), "Pick source", 0);
                }*/
                //Image From Gallery
                /*if (Build.VERSION.SDK_INT >= 23) {
                    if (Permission()) {
                        Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(pickPhotoIntent, PICK_IMAGE_REQUEST);
                    } else {
                        Permissioncall();
                    }
                } else {
                    Intent pickPhotoIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhotoIntent, PICK_IMAGE_REQUEST);
                }*/
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (getActivity().checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.CAMERA}, MY_CAMERA_PERMISSION_CODE);
                    } else {
                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(cameraIntent, CAMERA_REQUEST);
                    }
                }
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (edtComplainerName.getText().toString().equalsIgnoreCase("")) {
                    edtComplainerName.setError("Complain Name Required");
                    return;
                } else if (edtDescription.getText().toString().equalsIgnoreCase("")) {
                    edtDescription.setError("Description Required");
                    return;
                } else {
                    String path = getImage(filePath);
                    //Toast.makeText(getActivity(), path, Toast.LENGTH_SHORT).show();
                    if (!path.equals("")) {
                        try {
                            pd = new ProgressDialog(getActivity());
                            pd.setMessage("Please Wait...");
                            pd.setCancelable(false);
                            pd.show();
                            new MultipartUploadRequest(getActivity(), ConstantSp.BASE_URL + "user_management.php")
                                    .addParameter("action", "addComplainImage")
                                    .addParameter("userId",sp.getString(ConstantSp.ID,""))
                                    .addParameter("complainName", edtComplainerName.getText().toString())
                                    .addParameter("occupation", String.valueOf(spOccupation.getSelectedItem()))
                                    .addParameter("desc", edtDescription.getText().toString())
                                    .addParameter("complainType", sComplainType)
                                    .addParameter("address", sAddress)
                                    .addParameter("city", sCity)
                                    .addParameter("state", sState)
                                    .addParameter("country", sCountry)
                                    .addParameter("postcode", sPostcode)
                                    .addFileToUpload(path, "file")
                                    .setMaxRetries(2)
                                    .startUpload();
                            new Handler().postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    pd.dismiss();
                                    Toast.makeText(getActivity(), "Complain Added Successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getActivity(), HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                                }
                            }, 2500);
                        } catch (Exception exc) {
                            Toast.makeText(getActivity(), "Registration Unsuccessfully", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                            new addComplain().execute();
                        } else {
                            new ConnectionDetector(getActivity()).connectiondetect();
                        }
                    }
                }
            }
        });

        if(checkAndRequestPermission()){
            getCurrentLocation();
        }

        /*btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (documentList != null && !documentList.isEmpty()) {
                    uploadComplaintDocument();
                } else {
                    addComplaint("");
                }
                if(spComplaintType.getSelectedItem().equals("A.M.C Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","amc@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(getActivity(),
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else if(spComplaintType.getSelectedItem().equals("R.T.O Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","rto@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(getActivity(),
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else if(spComplaintType.getSelectedItem().equals("Food Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","food@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(getActivity(),
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });*/
    }

    private boolean checkAndRequestPermission() {
        List<String> listPermission = new ArrayList<>();
        for (String permission : appPermission){
            if(ContextCompat.checkSelfPermission(getActivity(),permission) != PackageManager.PERMISSION_GRANTED){
                listPermission.add(permission);
            }
        }
        if(!listPermission.isEmpty()){
            ActivityCompat.requestPermissions(getActivity(),listPermission.toArray(new String[listPermission.size()]),PERMISSION_CODE);
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_PERMISSION_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);
            } else {
                Toast.makeText(getActivity(), "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
        if(requestCode == PERMISSION_CODE){
            HashMap<String,Integer> permissionResult = new HashMap<>();
            int deniedCount = 0;
            for(int i=0;i< grantResults.length;i++){
                if(grantResults[i] == PackageManager.PERMISSION_DENIED){
                    permissionResult.put(permissions[i],grantResults[i]);
                    deniedCount++;
                }
            }
            if(deniedCount==0){
                getCurrentLocation();
            }
            else{
                for(Map.Entry<String,Integer> entry : permissionResult.entrySet()){
                    String permName = entry.getKey();
                    int permResult = entry.getValue();
                    if(ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),permName)){
                        showDialogPermission(
                                "",
                                "This App needs Location permission to work without any problems.",
                                "Yes, Grant Permissions",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        checkAndRequestPermission();
                                    }
                                },
                                "No",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        getActivity().finishAffinity();
                                    }
                                },
                                false
                        );
                    }
                    else{
                        showDialogPermission("",
                                "You have denied some permissions. Allow All permissions at Settings",
                                "Go to Settings",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getActivity().getPackageName(), null));
                                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        getActivity().finish();
                                    }
                                },
                                "No, Exit App", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        dialogInterface.dismiss();
                                        getActivity().finish();
                                    }
                                },
                                false
                        );
                    }
                }
            }
        }
    }

    public AlertDialog showDialogPermission(String title, String message, String positiveLable, DialogInterface.OnClickListener positiveClick,
                                            String negativeLable, DialogInterface.OnClickListener negativeClick, boolean isCancelable){
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(title);
        builder.setCancelable(isCancelable);
        builder.setMessage(message);
        builder.setPositiveButton(positiveLable,positiveClick);
        builder.setNegativeButton(negativeLable,negativeClick);
        AlertDialog alertDialog = builder.create();;
        alertDialog.show();
        return alertDialog;
    }

    private void getCurrentLocation() {
        GPSTracker gpsTracker = new GPSTracker(getActivity());
        if(gpsTracker.canGetLocation()){
            double doubleLatitude = gpsTracker.getLatitude();
            double doubleLongitude = gpsTracker.getLongitude();

            //Log.d("CURRENT_LOCATION",doubleLatitude+"\n"+doubleLongitude);

            Geocoder geocoder = new Geocoder(getActivity(), Locale.getDefault());
            List<Address> listAddress;

            try {
                listAddress = geocoder.getFromLocation(doubleLatitude,doubleLongitude,1);
                if(listAddress.size()<=0){

                }
                else {
                    sAddress = listAddress.get(0).getAddressLine(0);
                    sCity = listAddress.get(0).getLocality();
                    sState = listAddress.get(0).getAdminArea();
                    sCountry = listAddress.get(0).getCountryName();
                    //sCountryCode = listAddress.get(0).getCountryCode();
                    sPostcode = listAddress.get(0).getPostalCode();

                    //Log.d("CURRENT_LOCATION", sAddress + "\n" + sCity + "\n" + sState + "\n" + sCountry + "\n" + sCountryCode + "\n" + sPostCode);

                    address.setText(sAddress);
                    //latitude.setText(String.valueOf(doubleLatitude));
                    //longitude.setText(String.valueOf(doubleLongitude));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else{
            gpsTracker.showSettingsAlert();
        }
    }

    private boolean Permission() {
        int permissiocode = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        if (permissiocode == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void Permissioncall() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(getActivity(), "write external store..", Toast.LENGTH_SHORT).show();
        } else {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }

    private String getImage(Uri uri) {
        if (uri != null) {
            String path = null;
            String[] s_array = {MediaStore.Images.Media.DATA};
            Cursor c = getActivity().managedQuery(uri, s_array, null, null, null);
            int id = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            if (c.moveToFirst()) {
                do {
                    path = c.getString(id);
                }
                while (c.moveToNext());
                c.close();
                if (path != null) {
                    return path;
                }
            }
        }
        return "";
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            filePath = getImageUri(getActivity(), photo);
        }
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            //getPath(filePath);
            if (!filePath.equals("")) {
                try {
                    bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filePath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
            }
        } else {
            //Toast.makeText(LoginActivity.this, "Image Not Selected", Toast.LENGTH_SHORT).show();
        }
        EasyImage.handleActivityResult(requestCode, resultCode, data, getActivity(), new DefaultCallback() {
            @Override
            public void onImagePickerError(Exception e, EasyImage.ImageSource source, int type) {
                //Some error handling
                e.printStackTrace();
            }

            @Override
            public void onImagesPicked(@NonNull List<File> imageFiles, EasyImage.ImageSource source, int type) {
                onPhotosReturned(imageFiles);
            }

            @Override
            public void onCanceled(EasyImage.ImageSource source, int type) {
                //Cancel handling, you might wanna remove taken photo if it was canceled
                if (source == EasyImage.ImageSource.CAMERA) {
                    File photoFile = EasyImage.lastlyTakenButCanceledPhoto(getActivity());
                    if (photoFile != null) {
                        photoFile.delete();
                    }
                }
            }
        });
    }

    private void onPhotosReturned(List<File> returnedPhotos) {
        documentList = returnedPhotos;
        Log.e("TAG", "" + documentList.size());
    }

    @Override
    public void onPermissionGranted(int requestCode) {
        if (requestCode == 101) {
            EasyImage.openChooserWithGallery(getActivity(), "Pick source", 0);
        }
    }

    @Override
    public void onPermissionDeny(int requestCode) {

    }

    /*private void addComplaint(final String url) {
        final FirebaseUser user = mAuth.getCurrentUser();
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference(Constants.TABLE_COMPLAINT);
        ref.child(user.getUid()).push().setValue(new ReqAddComplaintModel(edtComplainerName.getText().toString().trim()
                , (String) spOccupation.getSelectedItem()
                , (String) spComplaintType.getSelectedItem()
                , edtDescription.getText().toString().trim()
                , url))
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(getActivity(), "Successfully added your complaint", Toast.LENGTH_LONG).show();
                        ((HomeActivity) getActivity()).hideProgressDialog();
                        ((HomeActivity) getActivity()).replaceFragment(new HomeFragment());
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
                ((HomeActivity) getActivity()).hideProgressDialog();
            }
        });

    }*/

    private class getType extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "complainType");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    strings = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        strings.add(jsonObject.getString("type"));
                    }
                    ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, strings);
                    spComplaintType.setAdapter(adapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class addComplain extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "addComplain");
            hashMap.put("userId",sp.getString(ConstantSp.ID,""));
            hashMap.put("complainName", edtComplainerName.getText().toString());
            hashMap.put("occupation", String.valueOf(spOccupation.getSelectedItem()));
            hashMap.put("desc", edtDescription.getText().toString());
            hashMap.put("complainType", sComplainType);
            hashMap.put("address", sAddress);
            hashMap.put("city", sCity);
            hashMap.put("state", sState);
            hashMap.put("country", sCountry);
            hashMap.put("pincode", sPostcode);
            hashMap.put("image", "");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getActivity(), HomeActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

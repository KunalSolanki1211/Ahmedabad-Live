package com.meri.aavaz;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Objects;

import com.meri.aavaz.fragment.AdminComplaintListFragment;
import com.meri.aavaz.utils.ConstantSp;


/**
 * A simple {@link Fragment} subclass.
 */
public class AdminDashboardFragment extends Fragment implements AdminDashboardAdapter.OnItemClickListener {

    SharedPreferences sp;
    ArrayList<AdminDashboardModel> homeList;

    public AdminDashboardFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin_dashboard, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sp = requireActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        final RecyclerView rvHome = view.findViewById(R.id.fragment_admin_dahsboard_rv);
        final GridLayoutManager gm = new GridLayoutManager(getActivity(), 2);
        rvHome.setLayoutManager(gm);
        homeList = new ArrayList<>();
        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
            homeList.add(new AdminDashboardModel(0, getString(R.string.type), R.drawable.logo_departments));
            homeList.add(new AdminDashboardModel(1, getString(R.string.view_complaint), R.drawable.logo_complaints));
            homeList.add(new AdminDashboardModel(2, getString(R.string.logout), R.drawable.logo_logout));
        } else {
            homeList.add(new AdminDashboardModel(0, getString(R.string.view_complaint), R.drawable.logo_complaints));
            homeList.add(new AdminDashboardModel(1, getString(R.string.logout), R.drawable.logo_logout));
        }
//        homeList.add(new HomeModel(5, getString(R.string.government_departments)));
        final AdminDashboardAdapter homeAdapter = new AdminDashboardAdapter(homeList);
        homeAdapter.setOnItemClickListener(this);
        //homeAdapter.addAll(homeList);
        rvHome.setAdapter(homeAdapter);
    }

    @Override
    public void onItemClickListener(int position) {
        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {

            switch (position) {
                case 0:
                    ((MainActivity) requireActivity()).replaceFragment(new AddDepartmentFragment());
                    break;
                case 1:
                    ((MainActivity) requireActivity()).replaceFragment(new AdminComplaintListFragment());
                    break;
                case 2:
                    sp.edit().clear().commit();
                    startActivity(new Intent(getActivity(), AuthorizationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;
            }
        } else {
            switch (position) {
                case 0:
                    ((MainActivity) requireActivity()).replaceFragment(new AdminComplaintListFragment());
                    break;
                case 1:
                    sp.edit().clear().commit();
                    startActivity(new Intent(getActivity(), AuthorizationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;
            }
        }
    }

}

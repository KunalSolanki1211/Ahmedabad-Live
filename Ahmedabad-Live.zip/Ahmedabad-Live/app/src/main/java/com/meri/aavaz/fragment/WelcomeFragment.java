package com.meri.aavaz.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import java.util.Objects;

import com.meri.aavaz.AuthorizationActivity;
import com.meri.aavaz.R;

public class WelcomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_welcome, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final Button btnLogin = view.findViewById(R.id.fragment_welcome_btn);
        final Button btnRegister = view.findViewById(R.id.fragment_welcome_register);

        btnLogin.setOnClickListener(view12 ->
            Navigation.findNavController(requireActivity(), R.id.navHostFragment).navigate(WelcomeFragmentDirections.actionWelcomeFragmentToLoginFragment())
        );

        btnRegister.setOnClickListener(view1 ->
            Navigation.findNavController(requireActivity(), R.id.navHostFragment).navigate(WelcomeFragmentDirections.actionWelcomeFragmentToRegisterFragment())
        );
    }
}

package com.meri.aavaz;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import net.gotev.uploadservice.MultipartUploadRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

public class ComplainDescActivity extends AppCompatActivity {

    String sComplainId, sComplainName, sType, sDesc, sOccupation, sComplain, sComplainStatus,sAddress;
    TextView tvName, tvType, tvDescription, tvOccupation, tvStatus,tvAddress;
    ImageView ivComplaint;
    ProgressBar progressBar;
    SharedPreferences sp;
    EditText reply_message;
    ImageView send;
    RecyclerView recyclerView;
    ArrayList<ComplainReplyList> complainReplyLists;
    ComplainReplyAdapter complainReplyAdapter;
    TextView solve;
    RelativeLayout replyLayout;
    ImageView attachment;

    private int PICK_PDF_REQUEST = 1;
    private static final int STORAGE_PERMISSION_CODE = 123;
    private Uri filePath;
    Cursor c = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complain_desc);
        requestStoragePermission();
        sp = getSharedPreferences(ConstantSp.PREF, MODE_PRIVATE);

        sComplainId = sp.getString(ConstantSp.COMPLAIN_ID, "");
        sComplainName = sp.getString(ConstantSp.COMPLAIN_NAME, "");
        sType = sp.getString(ConstantSp.COMPLAIN_TYPE, "");
        sDesc = sp.getString(ConstantSp.COMPLAIN_DESC, "");
        sOccupation = sp.getString(ConstantSp.COMPLAIN_OCCUPATION, "");
        sComplain = sp.getString(ConstantSp.COMPLAIN_URL, "");
        sComplainStatus = sp.getString(ConstantSp.COMPLAIN_STATUS, "");
        sAddress = sp.getString(ConstantSp.COMPLAIN_ADDRESS, "");

        reply_message = findViewById(R.id.complain_desc_message);
        send = findViewById(R.id.complain_desc_send);
        attachment = findViewById(R.id.complain_desc_attachment);

        attachment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("application/pdf");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
            }
        });

        solve = findViewById(R.id.complain_desc_solve);
        replyLayout = findViewById(R.id.complain_desc_reply_layout);

        /*if (sp.getString(ConstantSp.COMPLAIN_STATUS, "").equalsIgnoreCase("Solve")) {*/

        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
            //solve.setVisibility(View.GONE);
            if (sComplainStatus.equalsIgnoreCase("Solve")) {
                replyLayout.setVisibility(View.GONE);
                solve.setVisibility(View.GONE);
            } else {
                replyLayout.setVisibility(View.VISIBLE);
                solve.setVisibility(View.GONE);
            }
        } else if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
            //solve.setVisibility(View.GONE);
            if (sComplainStatus.equalsIgnoreCase("Solve")) {
                replyLayout.setVisibility(View.GONE);
                solve.setVisibility(View.GONE);
            } else {
                replyLayout.setVisibility(View.VISIBLE);
                solve.setVisibility(View.GONE); //VISIBLE
            }
        } else {
            //solve.setVisibility(View.VISIBLE);
            if (sComplainStatus.equalsIgnoreCase("Solve")) {
                replyLayout.setVisibility(View.GONE);
                solve.setVisibility(View.GONE);
            } else {
                replyLayout.setVisibility(View.VISIBLE);
                solve.setVisibility(View.VISIBLE);
            }
        }

        solve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (new ConnectionDetector(ComplainDescActivity.this).isConnectingToInternet()) {
                    new updateSolve().execute();
                } else {
                    new ConnectionDetector(ComplainDescActivity.this).connectiondetect();
                }
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (reply_message.getText().toString().equalsIgnoreCase("")) {
                    reply_message.setError("Reply Required");
                    return;
                } else {
                    if (new ConnectionDetector(ComplainDescActivity.this).isConnectingToInternet()) {
                        new addReply().execute();
                    } else {
                        new ConnectionDetector(ComplainDescActivity.this).connectiondetect();
                    }
                }
            }
        });

        recyclerView = findViewById(R.id.complain_desc_recycle);
        recyclerView.setLayoutManager(new LinearLayoutManager(ComplainDescActivity.this));
        recyclerView.setNestedScrollingEnabled(false);

        if (new ConnectionDetector(ComplainDescActivity.this).isConnectingToInternet()) {
            new getReplyData().execute();
            new getComplainData().execute();
        } else {
            new ConnectionDetector(ComplainDescActivity.this).connectiondetect();
        }

        tvName = findViewById(R.id.complaint_detail_tv_name);
        tvType = findViewById(R.id.complaint_detail_tv_type);
        tvDescription = findViewById(R.id.complaint_detail_tv_description);
        tvOccupation = findViewById(R.id.complaint_detail_tv_occupation);
        tvStatus = findViewById(R.id.complaint_detail_tv_status);
        tvAddress = findViewById(R.id.complaint_detail_tv_address);
        ivComplaint = findViewById(R.id.complaint_detail_iv);
        progressBar = findViewById(R.id.complain_detail_progressBar);

        progressBar.setVisibility(View.VISIBLE);
    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(ComplainDescActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;
        if (ActivityCompat.shouldShowRequestPermissionRationale(ComplainDescActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {

        }
        ActivityCompat.requestPermissions(ComplainDescActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == STORAGE_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(ComplainDescActivity.this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(ComplainDescActivity.this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            filePath = data.getData();
            String path = null;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                path = FilePath.getPath(this, filePath);
            }

            if (path == null) {

                Toast.makeText(this, "Please move your .pdf file to internal storage and retry", Toast.LENGTH_LONG).show();
            } else {
                //Uploading code
                try {
                    String uploadId = UUID.randomUUID().toString();
                    //Creating a multi part request
                    new MultipartUploadRequest(this, uploadId, ConstantSp.BASE_URL + "user_management.php")
                            .addParameter("action", "addReplyDocument")
                            .addParameter("complain_id", sComplainId)
                            .addParameter("userId", sp.getString(ConstantSp.ID, ""))
                            .addParameter("type", sp.getString(ConstantSp.TYPE, ""))
                            .addFileToUpload(path, "file") //Adding file
                            .setMaxRetries(2)
                            .startUpload(); //Starting the upload

                } catch (Exception exc) {
                    Toast.makeText(this, exc.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private class updateStatus extends AsyncTask<String, String, String> {
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "updateComplainStatus");
            hashMap.put("id", sComplainId);
            hashMap.put("receiveStatus", "Read");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }
    }

    private class updateSolve extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ComplainDescActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "updateComplainStatus");
            hashMap.put("id", sComplainId);
            hashMap.put("receiveStatus", "Solve");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(ComplainDescActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ComplainDescActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(ComplainDescActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class getReplyData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ComplainDescActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "getReply");
            hashMap.put("complain_id", sComplainId);
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    complainReplyLists = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        ComplainReplyList list = new ComplainReplyList();
                        list.setId(jsonObject.getString("id"));
                        list.setComplainId(jsonObject.getString("complain_id"));
                        list.setUserId(jsonObject.getString("userId"));
                        list.setName(jsonObject.getString("fname") + " " + jsonObject.getString("lname"));
                        list.setMessage(jsonObject.getString("reply"));
                        list.setDocument(jsonObject.getString("document"));
                        list.setDate(jsonObject.getString("created_date"));
                        complainReplyLists.add(list);
                    }
                    complainReplyAdapter = new ComplainReplyAdapter(ComplainDescActivity.this, complainReplyLists);
                    recyclerView.setAdapter(complainReplyAdapter);
                } else {
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class addReply extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ComplainDescActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "addReply");
            hashMap.put("complain_id", sComplainId);
            hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
            hashMap.put("reply", reply_message.getText().toString());
            hashMap.put("type", sp.getString(ConstantSp.TYPE, ""));
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(ComplainDescActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ComplainDescActivity.this, ComplainDescActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(ComplainDescActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class getComplainData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ComplainDescActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "getComplainDesc");
            hashMap.put("complain_id", sComplainId);
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        sp.edit().putString(ConstantSp.COMPLAIN_NAME, jsonObject.getString("complainName")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_DESC, jsonObject.getString("desc")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_TYPE, jsonObject.getString("complainType")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_OCCUPATION, jsonObject.getString("occupation")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_URL, jsonObject.getString("image")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_STATUS, jsonObject.getString("receiveStatus")).commit();
                        sp.edit().putString(ConstantSp.COMPLAIN_ADDRESS, jsonObject.getString("address")).commit();
                        Glide
                                .with(ComplainDescActivity.this)
                                .load(jsonObject.getString("image"))
                                .centerCrop()
                                .listener(new RequestListener<Drawable>() {
                                    @Override
                                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                                        progressBar.setVisibility(View.GONE);
                                        return false;
                                    }

                                    @Override
                                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                                        progressBar.setVisibility(View.GONE);
                                        return false;
                                    }
                                })
                                .into(ivComplaint);

                        tvName.setText(String.format("%s : %s"
                                , getString(R.string.name)
                                , jsonObject.getString("complainName")));

                        tvType.setText(String.format("%s : %s"
                                , getString(R.string.complaint_type)
                                , jsonObject.getString("complainType")));
                        tvDescription.setText(String.format("%s : %s"
                                , getString(R.string.complaint_description)
                                , jsonObject.getString("desc")));
                        tvOccupation.setText(String.format("%s : %s"
                                , getString(R.string.occupation)
                                , jsonObject.getString("occupation")));

                        tvAddress.setText(String.format("%s : %s"
                                , getString(R.string.address)
                                , jsonObject.getString("address")));

                        tvStatus.setText(String.format("%s : %s"
                                , getString(R.string.status)
                                , jsonObject.getString("receiveStatus")));
                        if (jsonObject.getString("receiveStatus").equalsIgnoreCase("Unread")) {
                            if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {

                            } else if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {

                            } else {
                                if (new ConnectionDetector(ComplainDescActivity.this).isConnectingToInternet()) {
                                    new updateStatus().execute();
                                } else {
                                    new ConnectionDetector(ComplainDescActivity.this).connectiondetect();
                                }
                            }
                        } else {

                        }
                    }
                } else {
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

package com.meri.aavaz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdminDashboardAdapter extends RecyclerView.Adapter<AdminDashboardAdapter.MyViewHolder> {


    private OnItemClickListener onItemClickListener;

    ArrayList<AdminDashboardModel> adminDashboardModels;

    public AdminDashboardAdapter(ArrayList<AdminDashboardModel> homeList) {
        this.adminDashboardModels = homeList;
    }


    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public interface OnItemClickListener {
        void onItemClickListener(int position);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_admin_dashboard, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        myViewHolder.tvTitle.setText(adminDashboardModels.get(i).getTitle());
        myViewHolder.image.setImageResource(adminDashboardModels.get(i).getImage());

        myViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClickListener(myViewHolder.getAdapterPosition());
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return adminDashboardModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        ImageView image;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.row_admin_dashboard_tv);
            image = itemView.findViewById(R.id.row_admin_dashboard_iv);
        }
    }
}


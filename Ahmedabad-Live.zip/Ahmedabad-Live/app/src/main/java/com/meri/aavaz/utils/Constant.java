package com.meri.aavaz.utils;


public class Constant {

    public static final String ADMINEmail = "publicservice1931@gmail.com";
    public static final String ADMINPassword = "SalDiploma$1";

    public static final String Message = "Attempt to Authenticate..";
    public static final String Emailotp = "Otp sent..your Emailid..";

    public static final String Smtphostkey = "mail.smtp.host";
    public static final String SmatphostValue = "smtp.gmail.com";

    public static final String Sslsocketportkey = "mail.smtp.socketFactory.port";
    public static final String SslsocketportValue = "465";

    public static final String Sslclassfactorykey = "mail.smtp.socketFactory.class";
    public static final String SslclassfactoryValue = "javax.net.ssl.SSLSocketFactory";

    public static final String Sslauthnticationkey = "mail.smtp.auth";
    public static final String SslauthnticationValue = "true";

    public static final String Sslsmtpportkey = "mail.smtp.port";
    public static final String SslsmtpportValue = "587";

    public static final String OTPMessage = "Otp Verification Code :";

    public static final String OTPSUBJECT = "OTP From Public Service";
}

package com.meri.aavaz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.Toast;

import com.meri.aavaz.adapter.ComplaintListAdapter;
import com.meri.aavaz.model.ReqAddComplaintModel;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AdminComplainListActivity extends AppCompatActivity {
    SharedPreferences sp;
    ComplaintListAdapter adapter;
    RecyclerView rvComplaintList;
    ArrayList<ReqAddComplaintModel> reqAddComplaintModels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_complain_list);
        sp = this.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        rvComplaintList = findViewById(R.id.fragment_complaint_list_rv);
        final LinearLayoutManager lm = new LinearLayoutManager(this);
        rvComplaintList.setLayoutManager(lm);
        rvComplaintList.addItemDecoration(new DividerItemDecoration(getApplicationContext(), lm.getOrientation()));
    }

    @Override
    public void onResume() {
        super.onResume();
        if (new ConnectionDetector(this).isConnectingToInternet()) {
            new getData().execute();
        } else {
            new ConnectionDetector(this).connectiondetect();
        }
    }

    private class getData extends AsyncTask<String, String, String> {
        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AdminComplainListActivity.this);
            pd.setCancelable(false);
            pd.setMessage("Please Wait...");
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getUserComplain");
                hashMap.put("userId", sp.getString(ConstantSp.ID, ""));
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            } else if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getAdminComplain");
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            } else {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("action", "getTypeComplain");
                hashMap.put("complainType",sp.getString(ConstantSp.TYPE,""));
                return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    reqAddComplaintModels = new ArrayList<>();
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        ReqAddComplaintModel list = new ReqAddComplaintModel();
                        list.setComplainerId(jsonObject.getString("id"));
                        list.setComplainerName(jsonObject.getString("complainName"));
                        list.setComplaintType(jsonObject.getString("complainType"));
                        list.setOccupation(jsonObject.getString("occupation"));
                        list.setDescription(jsonObject.getString("desc"));
                        list.setDocumentUrl(jsonObject.getString("image"));
                        list.setReceiveStatus(jsonObject.getString("receiveStatus"));
                        list.setAddress(jsonObject.getString("address"));
                        reqAddComplaintModels.add(list);
                    }
                    adapter = new ComplaintListAdapter(AdminComplainListActivity.this,reqAddComplaintModels);
                    rvComplaintList.setAdapter(adapter);
                } else {
                    Toast.makeText(AdminComplainListActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
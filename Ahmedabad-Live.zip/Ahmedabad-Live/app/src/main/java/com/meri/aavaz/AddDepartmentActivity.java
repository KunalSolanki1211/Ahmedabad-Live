package com.meri.aavaz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class AddDepartmentActivity extends AppCompatActivity {
    private EditText edtEmail;
    private EditText edtPassword;
    private EditText edtFirstName;
    private EditText edtLastName;
    private EditText edtAddress;
    private EditText edtMobile;
    private EditText edtArea;
    private EditText edtWordNo;
    private EditText edtDepartment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_department);
        edtEmail = findViewById(R.id.fragment_add_department_edt_email);
        edtPassword = findViewById(R.id.fragment_add_department_edt_password);
        edtFirstName = findViewById(R.id.fragment_add_department_edt_first_name);
        edtLastName = findViewById(R.id.fragment_add_department_edt_last_name);
        edtAddress = findViewById(R.id.fragment_add_department_edt_address);
        edtMobile = findViewById(R.id.fragment_add_department_edt_mobile);
        edtArea = findViewById(R.id.fragment_add_department_edt_area);
        edtWordNo = findViewById(R.id.fragment_add_department_edt_word_no);
        edtDepartment = findViewById(R.id.fragment_add_department_edt_add_department);
        final Button btnSubmit = findViewById(R.id.fragment_add_department_btn_submit);

        btnSubmit.setOnClickListener(view ->  {
                final String email = edtEmail.getText().toString().trim();
                final String password = edtPassword.getText().toString().trim();
                final String firstName = edtFirstName.getText().toString().trim();
                final String lastName = edtLastName.getText().toString().trim();
                final String address = edtAddress.getText().toString().trim();
                final String mobile = edtMobile.getText().toString().trim();
                final String area = edtArea.getText().toString().trim();
                final String wordNo = edtWordNo.getText().toString().trim();
                final String department = edtDepartment.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(firstName)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a first name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(lastName)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a last name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(address)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a address", Toast.LENGTH_SHORT).show();
                } else if (mobile.length() != 10) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter valid mobile", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(area)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter a area", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(department)) {
                    Toast.makeText(AddDepartmentActivity.this, "Please enter Department", Toast.LENGTH_SHORT).show();
                } else {
                    if (new ConnectionDetector(AddDepartmentActivity.this).isConnectingToInternet()) {
                        new addData().execute();
                    } else {
                        new ConnectionDetector(AddDepartmentActivity.this).connectiondetect();
                    }
                }
        });
    }

    private class addData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(AddDepartmentActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "departmentRegistration");
            hashMap.put("fname", edtFirstName.getText().toString());
            hashMap.put("lname", edtLastName.getText().toString());
            hashMap.put("cNo", edtMobile.getText().toString());
            hashMap.put("email", edtEmail.getText().toString());
            hashMap.put("password", edtPassword.getText().toString());
            hashMap.put("address", edtAddress.getText().toString());
            hashMap.put("area", edtArea.getText().toString());
            hashMap.put("wordNo", edtWordNo.getText().toString());
            hashMap.put("adhar", "");
            hashMap.put("type", edtDepartment.getText().toString());
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(AddDepartmentActivity.this, "Department Registered Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(AddDepartmentActivity.this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(AddDepartmentActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
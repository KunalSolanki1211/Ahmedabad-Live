package com.meri.aavaz;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

public class EditComplainActivity extends AppCompatActivity {

    String sName,sDesc,sType,sOccupation,sAddress;
    private List<File> documentList;

    private EditText edtComplainerName;
    private Spinner spOccupation;
    private Spinner spComplaintType;
    private EditText edtDescription;
    private EditText edtAddress;
    ArrayList<String> strings;
    String sComplainId,sSelectedType,sSelectedOccupation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_complain);
        Bundle bundle = getIntent().getExtras();
        sComplainId = bundle.getString("id");
        sName = bundle.getString("name");
        sDesc= bundle.getString("desc");
        sType= bundle.getString("type");
        sOccupation= bundle.getString("occupation");
        sAddress= bundle.getString("address");
        //Toast.makeText(this, sComplainId, Toast.LENGTH_SHORT).show();
        final Button btnSubmit = findViewById(R.id.fragment_edit_complaint_btn_submit);
        edtComplainerName = findViewById(R.id.fragment_edit_complaint_edt_name);
        spOccupation = findViewById(R.id.fragment_edit_complaint_sp_occupation);
        spComplaintType = findViewById(R.id.fragment_edit_complaint_sp_type);
        edtDescription = findViewById(R.id.fragment_edit_complaint_edt_description);
        edtAddress = findViewById(R.id.fragment_edit_complaint_edt_address);

        edtComplainerName.setText(sName);
        edtDescription.setText(sDesc);
        edtAddress.setText(sAddress);

        spOccupation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sSelectedOccupation = (String) adapterView.getItemAtPosition(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spComplaintType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sSelectedType = (String) adapterView.getItemAtPosition(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        if (new ConnectionDetector(EditComplainActivity.this).isConnectingToInternet()) {
            new getType().execute();
        } else {
            new ConnectionDetector(EditComplainActivity.this).connectiondetect();
        }

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtComplainerName.getText().toString().equalsIgnoreCase("")){
                    edtComplainerName.setError("Complainer Name Required");
                    return;
                }
                else if(edtDescription.getText().toString().equalsIgnoreCase("")){
                    edtDescription.setError("Description Required");
                    return;
                }
                else if(edtAddress.getText().toString().equalsIgnoreCase("")){
                    edtAddress.setError("Address Required");
                    return;
                }
                else{
                    if(new ConnectionDetector(EditComplainActivity.this).isConnectingToInternet()){
                        new updateComplain().execute();
                    }
                    else{
                        new ConnectionDetector(EditComplainActivity.this).connectiondetect();
                    }
                }
                /*DatabaseReference ref = FirebaseDatabase.getInstance().getReference("tb_complaint");
                Query applesQuery = ref.child("28vKxEumpLduVRFnav3xdsEtOpd2").orderByChild("description").equalTo(sDesc);

                applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot appleSnapshot : dataSnapshot.getChildren()) {
                            //appleSnapshot.getRef().removeValue();
                            appleSnapshot.getRef().child("complainerName").setValue(edtComplainerName.getText().toString());
                            appleSnapshot.getRef().child("complaintType").setValue(spComplaintType.getSelectedItem());
                            appleSnapshot.getRef().child("description").setValue(edtDescription.getText().toString());
                            appleSnapshot.getRef().child("occupation").setValue(spOccupation.getSelectedItem());
                            Toast.makeText(EditComplainActivity.this, "Record Updated Successfully", Toast.LENGTH_SHORT).show();
                            EditComplainActivity.super.onBackPressed();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.e("RESPONSE", "onCancelled", databaseError.toException());
                    }
                });*/

                /*if(spComplaintType.getSelectedItem().equals("A.M.C Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","amc@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(EditComplainActivity.this,
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else if(spComplaintType.getSelectedItem().equals("R.T.O Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","rto@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(EditComplainActivity.this,
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }
                else if(spComplaintType.getSelectedItem().equals("Food Department")){
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("text/plain");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{
                            "admin@gmail.com","food@gmail.com" });
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "New Complain From "+edtComplainerName.getText().toString());
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, spOccupation.getSelectedItem()+" "+edtDescription.getText().toString());
                    emailIntent.setType("message/rfc822");
                    try {
                        startActivity(Intent.createChooser(emailIntent,
                                "Send email using..."));
                    } catch (android.content.ActivityNotFoundException ex) {
                        Toast.makeText(EditComplainActivity.this,
                                "No email clients installed.",
                                Toast.LENGTH_SHORT).show();
                    }
                }*/
            }
        });

    }

    private class getType extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(EditComplainActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "complainType");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    strings = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        strings.add(jsonObject.getString("type"));
                    }
                    ArrayAdapter adapter = new ArrayAdapter(EditComplainActivity.this, android.R.layout.simple_list_item_1, strings);
                    spComplaintType.setAdapter(adapter);
                } else {
                    Toast.makeText(EditComplainActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class updateComplain extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(EditComplainActivity.this);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("action","updateComplain");
            hashMap.put("id",sComplainId);
            hashMap.put("complainName",edtComplainerName.getText().toString());
            hashMap.put("occupation",sSelectedOccupation);
            hashMap.put("desc",edtDescription.getText().toString());
            hashMap.put("complainType", sSelectedType);
            hashMap.put("address", sAddress);
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL+"user_management.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equalsIgnoreCase("True")){
                    Toast.makeText(EditComplainActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    EditComplainActivity.super.onBackPressed();
                }
                else{
                    Toast.makeText(EditComplainActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

package com.meri.aavaz;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

public class ForgotPasswordActivity extends AppCompatActivity {

    EditText email, new_pass, confirm_pass;
    String semail, spass;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    Button submit;
    CheckBox check_password, check_cpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        email = (EditText) findViewById(R.id.forgot_password_email);
        new_pass = (EditText) findViewById(R.id.forgot_password_password);
        confirm_pass = (EditText) findViewById(R.id.forgot_password_cpassword);
        check_password = (CheckBox) findViewById(R.id.forgot_password_check);
        check_cpassword = (CheckBox) findViewById(R.id.forgot_cpassword_check);
        submit = (Button) findViewById(R.id.forgot_password_submit);

        check_password.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    new_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    new_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }

            }
        });

        check_cpassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (!isChecked) {
                    confirm_pass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else {
                    confirm_pass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }

            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                semail = email.getText().toString();
                if (semail.matches(emailPattern)) {
                } else {
                    Toast.makeText(ForgotPasswordActivity.this, "In Valid Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (email.getText().toString().equalsIgnoreCase("")) {
                    email.setError("Email Id Required");
                    return;
                } else if (new_pass.getText().toString().equalsIgnoreCase("")) {
                    new_pass.setError("Password Required");
                    return;
                } else {
                    String snew_pass = new_pass.getText().toString();
                    String sconfirm_pass = confirm_pass.getText().toString();
                    if (snew_pass.equals(sconfirm_pass)) {
                        if (new ConnectionDetector(ForgotPasswordActivity.this).isConnectingToInternet()) {
                            spass = new_pass.getText().toString();
                            new forgotPass().execute();
                        } else {
                            new ConnectionDetector(ForgotPasswordActivity.this).connectiondetect();
                        }
                    } else {
                        confirm_pass.setError("Password Does Not Match");
                    }
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == android.R.id.home) {
            super.onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    private class forgotPass extends AsyncTask<String,String,String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(ForgotPasswordActivity.this);
            pd.setMessage("Please Wait");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String,String> hashMap = new HashMap<>();
            hashMap.put("action","forgotPassword");
            hashMap.put("email",email.getText().toString());
            hashMap.put("password",new_pass.getText().toString());
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL+"user_management.php",MakeServiceCall.POST,hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if(object.getString("Status").equalsIgnoreCase("True")){
                    Toast.makeText(ForgotPasswordActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                    onBackPressed();
                }
                else{
                    Toast.makeText(ForgotPasswordActivity.this, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}


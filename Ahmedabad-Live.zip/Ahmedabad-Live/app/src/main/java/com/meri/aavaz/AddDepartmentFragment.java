package com.meri.aavaz;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import com.meri.aavaz.fragment.RegisterFragment;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;


/**
 * A simple {@link Fragment} subclass.
 */
public class AddDepartmentFragment extends Fragment {

    private static final String TAG = RegisterFragment.class.getSimpleName();

    private EditText edtEmail;
    private EditText edtPassword;
    private EditText edtFirstName;
    private EditText edtLastName;
    private EditText edtAddress;
    private EditText edtMobile;
    private EditText edtArea;
    private EditText edtWordNo;
    private EditText edtDepartment;

    public AddDepartmentFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_department, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        edtEmail = view.findViewById(R.id.fragment_add_department_edt_email);
        edtPassword = view.findViewById(R.id.fragment_add_department_edt_password);
        edtFirstName = view.findViewById(R.id.fragment_add_department_edt_first_name);
        edtLastName = view.findViewById(R.id.fragment_add_department_edt_last_name);
        edtAddress = view.findViewById(R.id.fragment_add_department_edt_address);
        edtMobile = view.findViewById(R.id.fragment_add_department_edt_mobile);
        edtArea = view.findViewById(R.id.fragment_add_department_edt_area);
        edtWordNo = view.findViewById(R.id.fragment_add_department_edt_word_no);
        edtDepartment = view.findViewById(R.id.fragment_add_department_edt_add_department);
        final Button btnSubmit = view.findViewById(R.id.fragment_add_department_btn_submit);

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = edtEmail.getText().toString().trim();
                final String password = edtPassword.getText().toString().trim();
                final String firstName = edtFirstName.getText().toString().trim();
                final String lastName = edtLastName.getText().toString().trim();
                final String address = edtAddress.getText().toString().trim();
                final String mobile = edtMobile.getText().toString().trim();
                final String area = edtArea.getText().toString().trim();
                final String wordNo = edtWordNo.getText().toString().trim();
                final String department = edtDepartment.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(firstName)) {
                    Toast.makeText(getActivity(), "Please enter a first name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(lastName)) {
                    Toast.makeText(getActivity(), "Please enter a last name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(address)) {
                    Toast.makeText(getActivity(), "Please enter a address", Toast.LENGTH_SHORT).show();
                } else if (mobile.length() < 10 || mobile.length() > 10) {
                    Toast.makeText(getActivity(), "Please enter valid mobile", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(area)) {
                    Toast.makeText(getActivity(), "Please enter a area", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(department)) {
                    Toast.makeText(getActivity(), "Please enter Department", Toast.LENGTH_SHORT).show();
                } else {
                    if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                        new addData().execute();
                    } else {
                        new ConnectionDetector(getActivity()).connectiondetect();
                    }
                }
            }
        });

    }


    private class addData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "departmentRegistration");
            hashMap.put("fname", edtFirstName.getText().toString());
            hashMap.put("lname", edtLastName.getText().toString());
            hashMap.put("cNo", edtMobile.getText().toString());
            hashMap.put("email", edtEmail.getText().toString());
            hashMap.put("password", edtPassword.getText().toString());
            hashMap.put("address", edtAddress.getText().toString());
            hashMap.put("area", edtArea.getText().toString());
            hashMap.put("wordNo", edtWordNo.getText().toString());
            hashMap.put("adhar", "");
            hashMap.put("type", edtDepartment.getText().toString());
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(getActivity(), "Department Registered Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(getActivity(), MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

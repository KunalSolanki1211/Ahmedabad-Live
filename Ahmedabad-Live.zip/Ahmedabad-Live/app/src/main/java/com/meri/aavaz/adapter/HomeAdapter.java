package com.meri.aavaz.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.meri.aavaz.R;
import com.meri.aavaz.common.AppAdapter;
import com.meri.aavaz.model.HomeModel;

public class HomeAdapter extends AppAdapter<RecyclerView.ViewHolder, HomeModel> {


    private OnItemClickListener onItemClickListener;


    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final HomeModel homeModel = getItem(position);
        final TextView tvTitle = holder.itemView.findViewById(R.id.row_home_tv);
        final ImageView imageView = holder.itemView.findViewById(R.id.row_home_iv);
        tvTitle.setText(homeModel.getTitle());
        imageView.setImageResource(homeModel.getImage());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClickListener(holder.getAdapterPosition());
                }
            }
        });

    }

    @Override
    protected int getViewId() {
        return R.layout.row_home;
    }

    public interface OnItemClickListener {
        void onItemClickListener(int position);
    }
}

package com.meri.aavaz.common;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Collection;

import com.meri.aavaz.model.HomeModel;


public abstract class AppAdapter<holder extends RecyclerView.ViewHolder, T extends HomeModel> extends AppHolderAdapter<holder, T> {
    private ArrayList<T> items = new ArrayList<T>();

    public AppAdapter() {
        setHasStableIds(true);
    }


    public void add(T object) {
        items.add(object);
        notifyDataSetChanged();
    }

    public void add(int index, T object) {
        items.add(index, object);
        notifyDataSetChanged();
    }

    public void addAll(Collection<? extends T> collection) {
        if (collection != null) {
            items.addAll(collection);
            notifyDataSetChanged();
        }
    }

    public void append(Collection<? extends T> collection, int startPoint, int size) {
        if (collection != null) {
            items.addAll(collection);
            notifyItemRangeInserted(startPoint, size);
        }
    }

    public void clear() {
        items.clear();
        notifyDataSetChanged();
    }

    public void remove(String object) {
        items.remove(object);
        notifyDataSetChanged();
    }

    public void remove(T object) {
        items.remove(object);
        notifyDataSetChanged();
    }

    public HomeModel getItem(int position) {
        return items.get(position);
    }


    @Override
    public long getItemId(int position) {
        return getItem(position).hashCode();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public void removeEdit(T object) {
        items.remove(object);
        notifyDataSetChanged();
    }

    public void remove(int position) {
        items.remove(position);
        notifyItemRemoved(position);
    }
    public void removeAndRefreshList(int position) {
        items.remove(position);
        notifyDataSetChanged();
    }


    public ArrayList<T> getItems() {
        return items;
    }



}

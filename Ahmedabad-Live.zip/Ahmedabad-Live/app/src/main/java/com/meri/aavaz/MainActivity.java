package com.meri.aavaz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.meri.aavaz.utils.ProgressUtils;

public class MainActivity extends AppCompatActivity {
    private static MainActivity instance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        instance = this;
        //replaceFragment(new AdminComplaintListFragment());
        replaceFragment(new AdminDashboardFragment());
    }

    public static MainActivity getInstance()    {
        return instance;
    }

    public void replaceFragment(final Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.container, fragment, fragment.getClass().getSimpleName())
                .addToBackStack("")
                .commit();
    }

    public void addFragment(final Fragment nextFragment, final Fragment currentFragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .add(R.id.container, nextFragment, nextFragment.getClass().getSimpleName())
                .hide(currentFragment)
                .addToBackStack(nextFragment.getClass().getSimpleName())
                .commit();
    }


    public void showProgressDialog() {
        ProgressUtils.getInstance(this).show();
    }

    public void hideProgressDialog() {
        ProgressUtils.getInstance(this).close();
    }

}

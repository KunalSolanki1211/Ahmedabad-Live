package com.meri.aavaz.fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

/*import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;*/

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import com.meri.aavaz.AdminActivity;
import com.meri.aavaz.ForgotPasswordActivity;
import com.meri.aavaz.HomeActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

/**
 * Created by mavyasoni on 25/02/18.
 */

public class LoginFragment extends Fragment {

    private static final String TAG = LoginFragment.class.getSimpleName();
    //private FirebaseAuth mAuth;
    ProgressDialog pd;
    TextView tvSignIn;
    EditText edtEmail, edtPassword;
    SharedPreferences sp;
    ArrayList<String> strings;
    Spinner spinner;
    String sType;
    TextView forgotPassword;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        //mAuth = FirebaseAuth.getInstance();
        sp = requireActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        tvSignIn = view.findViewById(R.id.fragment_login_tv_sign_in);
        edtEmail = view.findViewById(R.id.fragment_login_edt_email);
        edtPassword = view.findViewById(R.id.fragment_login_edt_password);
        forgotPassword = view.findViewById(R.id.login_forgot_password);
        final Button btnLogin = view.findViewById(R.id.fragment_login_btn_login);
        spinner = view.findViewById(R.id.login_type);

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), ForgotPasswordActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sType = String.valueOf(adapterView.getSelectedItem());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtEmail.getText().toString())) {
                    Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(edtPassword.getText().toString())) {
                    Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
                } else {
                    final String email = edtEmail.getText().toString().trim();
                    final String password = edtPassword.getText().toString().trim();
                    //login(email, password);
                    if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                        new loginData().execute();
                    } else {
                        new ConnectionDetector(getActivity()).connectiondetect();
                    }
                }
            }
        });

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getType().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        tvSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Navigation.findNavController(requireActivity(), R.id.navHostFragment).navigate(LoginFragmentDirections.actionLoginFragmentToRegisterFragment());
            }
        });

    }

    private class getType extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "type");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    strings = new ArrayList<>();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        strings.add(jsonObject.getString("type"));
                    }
                    ArrayAdapter adapter = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, strings);
                    spinner.setAdapter(adapter);
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class loginData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "login");
            hashMap.put("type", sType);
            hashMap.put("email", edtEmail.getText().toString());
            hashMap.put("password", edtPassword.getText().toString());
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        sp.edit().putString(ConstantSp.ID, jsonObject.getString("id")).commit();
                        sp.edit().putString(ConstantSp.FNAME, jsonObject.getString("fname")).commit();
                        sp.edit().putString(ConstantSp.LNAME, jsonObject.getString("lname")).commit();
                        sp.edit().putString(ConstantSp.CNO, jsonObject.getString("cNo")).commit();
                        sp.edit().putString(ConstantSp.EMAIL, jsonObject.getString("email")).commit();
                        sp.edit().putString(ConstantSp.PASSWORD, jsonObject.getString("password")).commit();
                        sp.edit().putString(ConstantSp.ADDRESS, jsonObject.getString("address")).commit();
                        sp.edit().putString(ConstantSp.AREA, jsonObject.getString("area")).commit();
                        sp.edit().putString(ConstantSp.WORDNO, jsonObject.getString("wordNo")).commit();
                        sp.edit().putString(ConstantSp.ADHAR, jsonObject.getString("adhar")).commit();
                        sp.edit().putString(ConstantSp.TYPE, jsonObject.getString("type")).commit();
                    }
                    if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
                        final Intent intent = new Intent(getActivity(), HomeActivity.class);
                        startActivity(intent);
                        requireActivity().finish();
                    } else {
                        final Intent intent = new Intent(getActivity(), AdminActivity.class);
                        startActivity(intent);
                        requireActivity().finish();
                    }
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

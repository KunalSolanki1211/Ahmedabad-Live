package com.meri.aavaz.adapter;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

import com.meri.aavaz.ComplainDescActivity;
import com.meri.aavaz.EditComplainActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.model.ReqAddComplaintModel;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

public class ComplaintListAdapter extends RecyclerView.Adapter<ComplaintListAdapter.MyViewHolder> {

    Context context;
    ArrayList<ReqAddComplaintModel> reqAddComplaintModels;
    String sComplainId;
    SharedPreferences sp;
    int iPosition;

    public ComplaintListAdapter(FragmentActivity activity, ArrayList<ReqAddComplaintModel> reqAddComplaintModels) {
        this.context = activity;
        this.reqAddComplaintModels = reqAddComplaintModels;
        sp = context.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_complaint, viewGroup, false);
        return new MyViewHolder(itemView);
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvType, tvDescription, tvOccupation, tvStatus,tvAddress;
        final ImageView ivComplaint;
        TextView edit, delete;
        ProgressBar progressBar;
        LinearLayout card;
        ConstraintLayout constraintLayout;

        public MyViewHolder(View view) {
            super(view);
            tvName = itemView.findViewById(R.id.row_complaint_tv_name);
            tvType = itemView.findViewById(R.id.row_complaint_tv_type);
            tvDescription = itemView.findViewById(R.id.row_complaint_tv_description);
            tvOccupation = itemView.findViewById(R.id.row_complaint_tv_occupation);
            tvStatus = itemView.findViewById(R.id.row_complaint_tv_status);
            tvAddress = itemView.findViewById(R.id.row_complaint_tv_address);
            ivComplaint = itemView.findViewById(R.id.row_complaint_iv);
            edit = itemView.findViewById(R.id.row_complaint_edit);
            delete = itemView.findViewById(R.id.row_complaint_delete);
            progressBar = itemView.findViewById(R.id.progressBar);
            card = itemView.findViewById(R.id.row_complain_card);
            constraintLayout = itemView.findViewById(R.id.row_complain_constraint);
        }
    }

    @Override
    public void onBindViewHolder(final MyViewHolder holder, final int position) {
        //final ReqAddComplaintModel reqAddComplaintModels.get(position) = getItem(position);

        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
            if(reqAddComplaintModels.get(position).getReceiveStatus().equalsIgnoreCase("Solve")){
                holder.edit.setVisibility(View.GONE);
            }
            else{
                holder.edit.setVisibility(View.VISIBLE);
            }
        } else if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
            holder.edit.setVisibility(View.VISIBLE);
        } else {
            holder.edit.setVisibility(View.GONE);
        }

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, EditComplainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("id", reqAddComplaintModels.get(position).getComplainerId());
                bundle.putString("name", reqAddComplaintModels.get(position).getComplainerName());
                bundle.putString("desc", reqAddComplaintModels.get(position).getDescription());
                bundle.putString("type", reqAddComplaintModels.get(position).getComplaintType());
                bundle.putString("occupation", reqAddComplaintModels.get(position).getOccupation());
                bundle.putString("address", reqAddComplaintModels.get(position).getAddress());
                intent.putExtras(bundle);
                context.startActivity(intent);

                /*DatabaseReference ref = FirebaseDatabase.getInstance().getReference("tb_complaint");
                Query applesQuery = ref.child("28vKxEumpLduVRFnav3xdsEtOpd2").orderByChild("description").equalTo(reqAddComplaintModels.get(position).getDescription());

                applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Toast.makeText(context, "Yes", Toast.LENGTH_SHORT).show();
                        for (DataSnapshot appleSnapshot : dataSnapshot.getChildren()) {
                            //appleSnapshot.getRef().removeValue();
                            appleSnapshot.getRef().child("complainerName").setValue("sagar123");
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.e("RESPONSE", "onCancelled", databaseError.toException());
                    }
                });*/
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                iPosition = position;
                if (new ConnectionDetector(context).isConnectingToInternet()) {
                    sComplainId = reqAddComplaintModels.get(position).getComplainerId();
                    new deleteData().execute();
                } else {
                    new ConnectionDetector(context).connectiondetect();
                }
                /*DatabaseReference ref = FirebaseDatabase.getInstance().getReference("tb_complaint");
                Query applesQuery = ref.child("28vKxEumpLduVRFnav3xdsEtOpd2").orderByChild("description").equalTo(reqAddComplaintModels.get(position).getDescription());

                applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Toast.makeText(context, "Complain Deleted Successfully", Toast.LENGTH_SHORT).show();
                        for (DataSnapshot appleSnapshot : dataSnapshot.getChildren()) {
                            appleSnapshot.getRef().removeValue();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.e("RESPONSE", "onCancelled", databaseError.toException());
                    }
                });*/
            }
        });

        holder.tvName.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.name)
                , reqAddComplaintModels.get(position).getComplainerName()));

        holder.tvStatus.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.status)
                , reqAddComplaintModels.get(position).getReceiveStatus()));

        holder.tvType.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.complaint_type)
                , reqAddComplaintModels.get(position).getComplaintType()));
        holder.tvDescription.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.complaint_description)
                , reqAddComplaintModels.get(position).getDescription()));
        holder.tvOccupation.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.occupation)
                , reqAddComplaintModels.get(position).getOccupation()));
        holder.tvAddress.setText(String.format("%s : %s"
                , holder.itemView.getContext().getString(R.string.address)
                , reqAddComplaintModels.get(position).getAddress()));
        holder.progressBar.setVisibility(View.VISIBLE);
        Glide
                .with(holder.itemView.getContext())
                .load(reqAddComplaintModels.get(position).getDocumentUrl())
                .centerCrop()
                .listener(new RequestListener<Drawable>() {
                    @Override
                    public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {
                        holder.progressBar.setVisibility(View.GONE);
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {
                        holder.progressBar.setVisibility(View.GONE);
                        return false;
                    }
                })
                .into(holder.ivComplaint);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, ComplainDescActivity.class);
                sp.edit().putString(ConstantSp.COMPLAIN_ID, reqAddComplaintModels.get(position).getComplainerId()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_TYPE, reqAddComplaintModels.get(position).getComplaintType()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_DESC, reqAddComplaintModels.get(position).getDescription()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_OCCUPATION, reqAddComplaintModels.get(position).getOccupation()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_URL, reqAddComplaintModels.get(position).getDocumentUrl()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_STATUS, reqAddComplaintModels.get(position).getReceiveStatus()).commit();
                sp.edit().putString(ConstantSp.COMPLAIN_ADDRESS, reqAddComplaintModels.get(position).getAddress()).commit();
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return reqAddComplaintModels.size();
    }

    private class deleteData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(context);
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "deleteComplain");
            hashMap.put("id", sComplainId);
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("User")) {
                        /*final Intent intent = new Intent(context, HomeActivity.class);
                        context.startActivity(intent);*/
                        reqAddComplaintModels.remove(iPosition);
                        notifyDataSetChanged();
                    } else {
                        /*final Intent intent = new Intent(context, AdminActivity.class);
                        context.startActivity(intent);*/
                        reqAddComplaintModels.remove(iPosition);
                        notifyDataSetChanged();
                    }
                } else {
                    Toast.makeText(context, object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /*@Override
    protected int getViewId() {
        return R.layout.row_complaint;
    }*/
}

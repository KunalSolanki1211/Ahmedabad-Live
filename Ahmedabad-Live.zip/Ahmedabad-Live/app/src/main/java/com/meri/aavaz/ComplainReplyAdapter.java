package com.meri.aavaz;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class ComplainReplyAdapter extends RecyclerView.Adapter<ComplainReplyAdapter.MyHolder> {

    Context context;
    ArrayList<ComplainReplyList> complainReplyLists;

    public ComplainReplyAdapter(ComplainDescActivity complainDescActivity, ArrayList<ComplainReplyList> complainReplyLists) {
        this.context = complainDescActivity;
        this.complainReplyLists = complainReplyLists;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.row_complaint_reply, viewGroup, false);
        return new MyHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder myHolder, final int i) {
        myHolder.name.setText(complainReplyLists.get(i).getName());
        myHolder.message.setText(complainReplyLists.get(i).getMessage());
        myHolder.date.setText(complainReplyLists.get(i).getDate());
        if (complainReplyLists.get(i).getDocument().equalsIgnoreCase("")) {
            myHolder.download.setVisibility(View.GONE);
        } else {
            myHolder.download.setVisibility(View.VISIBLE);
        }

        myHolder.download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.parse("http://docs.google.com/viewer?url=" + complainReplyLists.get(i).getDocument()), "text/html");
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return complainReplyLists.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView name, message, date, download;

        public MyHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.row_complain_reply_name);
            message = itemView.findViewById(R.id.row_complain_reply_message);
            date = itemView.findViewById(R.id.row_complain_reply_date);
            download = itemView.findViewById(R.id.row_complain_reply_download);
        }
    }
}

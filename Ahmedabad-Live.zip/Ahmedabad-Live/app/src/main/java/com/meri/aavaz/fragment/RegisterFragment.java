package com.meri.aavaz.fragment;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

//import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.meri.aavaz.AuthorizationActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;
import com.meri.aavaz.utils.SendMail;

/**
 * Created by mavyasoni on 25/02/18.
 */

public class RegisterFragment extends Fragment {

    private static final String TAG = RegisterFragment.class.getSimpleName();

    private EditText edtEmail;
    private EditText edtPassword;
    private EditText edtFirstName;
    private EditText edtLastName;
    private EditText edtAddress;
    private EditText edtMobile;
    private EditText edtArea;
    private EditText edtWordNo;
    private EditText edtAadharCard;
    ProgressDialog pd;
    //private FirebaseAuth mAuth;

    EditText otp;
    Button verify;
    LinearLayout constraintLayout;
    LinearLayout linearLayout;
    String sRendom;

    private String verificationId;
    private FirebaseAuth mAuth;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_register, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        edtEmail = view.findViewById(R.id.fragment_register_edt_email);
        edtPassword = view.findViewById(R.id.fragment_register_edt_password);
        edtFirstName = view.findViewById(R.id.fragment_register_edt_first_name);
        edtLastName = view.findViewById(R.id.fragment_register_edt_last_name);
        edtAddress = view.findViewById(R.id.fragment_register_edt_address);
        edtMobile = view.findViewById(R.id.fragment_register_edt_mobile);
        edtArea = view.findViewById(R.id.fragment_register_edt_area);
        edtWordNo = view.findViewById(R.id.fragment_register_edt_word_no);
        edtAadharCard = view.findViewById(R.id.fragment_register_edt_aadhar_card_no);
        //mAuth = FirebaseAuth.getInstance();
        final Button btnSubmit = view.findViewById(R.id.fragment_register_btn_submit);

        otp = view.findViewById(R.id.fragment_register_edt_otp);
        verify = view.findViewById(R.id.fragment_register_btn_varify);
        constraintLayout = view.findViewById(R.id.register_constrain);
        linearLayout = view.findViewById(R.id.register_otp);

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verifyCode(otp.getText().toString());
                /*if (otp.getText().toString().equals(sRendom)) {
                    Toast.makeText(getActivity(), "Varified", Toast.LENGTH_SHORT).show();
                    final String email = edtEmail.getText().toString().trim();
                    final String password = edtPassword.getText().toString().trim();
                    createAccount(email, password);
                } else {
                    Toast.makeText(getActivity(), "UnSuccess", Toast.LENGTH_SHORT).show();
                }*/
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email = edtEmail.getText().toString().trim();
                final String password = edtPassword.getText().toString().trim();
                final String firstName = edtFirstName.getText().toString().trim();
                final String lastName = edtLastName.getText().toString().trim();
                final String address = edtAddress.getText().toString().trim();
                final String mobile = edtMobile.getText().toString().trim();
                final String area = edtArea.getText().toString().trim();
                final String wordNo = edtWordNo.getText().toString().trim();
                final String aadharCard = edtAadharCard.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(firstName)) {
                    Toast.makeText(getActivity(), "Please enter a first name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(lastName)) {
                    Toast.makeText(getActivity(), "Please enter a last name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(address)) {
                    Toast.makeText(getActivity(), "Please enter a address", Toast.LENGTH_SHORT).show();
                } else if (mobile.length() != 10) {
                    Toast.makeText(getActivity(), "Please enter valid mobile", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(area)) {
                    Toast.makeText(getActivity(), "Please enter a area", Toast.LENGTH_SHORT).show();
                } else if (aadharCard.length() != 12) {
                    Toast.makeText(getActivity(), "Please enter valid Aadhar Card", Toast.LENGTH_SHORT).show();
                } else {
                    /*final Random random = new Random();
                    sRendom = String.valueOf(random.nextInt(1000000) + 1);
                    new OTP(getActivity(), email, Constant.OTPSUBJECT, "Hi,\t" + email + "\n" + Constant.OTPMessage + sRendom).execute();
                    constraintLayout.setVisibility(View.GONE);
                    linearLayout.setVisibility(View.VISIBLE);
                    Toast.makeText(getActivity(), "Check Your Mail For OTP", Toast.LENGTH_SHORT).show();*/
                    sendVerificationCode("+91" + mobile);
                    constraintLayout.setVisibility(View.GONE);
                    linearLayout.setVisibility(View.VISIBLE);
//                    createAccount(email, password);
                }
            }
        });

    }

    private void verifyCode(String code) {
        //Log.d("RESPONSE", verificationId + "\n" + code);
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //Toast.makeText(getActivity(), "Success", Toast.LENGTH_SHORT).show();
                            final String email = edtEmail.getText().toString().trim();
                            final String password = edtPassword.getText().toString().trim();
                            createAccount(email, password);

                            /*if (sp.getString(ConstantSp.OTP, "").equalsIgnoreCase(sOTP)) {
                                sp.edit().putString(ConstantSp.OTP_VARIFY, "1").commit();
                                pd = new ProgressDialog(getActivity());
                                pd.setMessage("Please Wait...");
                                pd.setCancelable(false);
                                pd.show();
                                doLogin();
                            } else {
                                new ToastIntentClass(getActivity(), "OTP Does Not Match!!!");
                            }*/
                        } else {
                            Toast.makeText(getActivity(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void sendVerificationCode(String number) {
        /*PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBack
        );*/
        //Log.d("RESPONSE", number);
        PhoneAuthOptions options = PhoneAuthOptions.newBuilder()
                        .setPhoneNumber(number)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(requireActivity())
                        .setCallbacks(mCallBack)
                        .build();
        PhoneAuthProvider.verifyPhoneNumber(options);
        /*PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                60,
                TimeUnit.SECONDS,
                getActivity(),
                mCallBack
        );*/
    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationId = s;
        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                char[] array = code.toCharArray();
                for (int i = 0; i < array.length; i++) {

                }
                //editText.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Log.e("OTP_ERROR", e.getMessage());
            Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };

    private void createAccount(final String email, String password) {
        final String firstName = edtFirstName.getText().toString().trim();
        final String lastName = edtLastName.getText().toString().trim();
        final String address = edtAddress.getText().toString().trim();
        final String mobile = edtMobile.getText().toString().trim();
        final String area = edtArea.getText().toString().trim();
        final String wordNo = edtWordNo.getText().toString().trim();
        final String aadharCard = edtAadharCard.getText().toString().trim();
        Log.d(TAG, "createAccount:" + email);
        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(firstName)) {
            Toast.makeText(getActivity(), "Please enter a first name", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(lastName)) {
            Toast.makeText(getActivity(), "Please enter a last name", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(address)) {
            Toast.makeText(getActivity(), "Please enter a address", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(mobile)) {
            Toast.makeText(getActivity(), "Please enter a mobile", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(area)) {
            Toast.makeText(getActivity(), "Please enter a area", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(aadharCard)) {
            Toast.makeText(getActivity(), "Please enter a Aadhar Card", Toast.LENGTH_SHORT).show();
        } else {
            if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                /*pd = new ProgressDialog(getActivity());
                pd.setMessage("Please Wait...");
                pd.setCancelable(false);
                pd.show();*/
                new addData().execute();
            } else {
                new ConnectionDetector(getActivity()).connectiondetect();
            }
            /*((AuthorizationActivity) Objects.requireNonNull(getActivity())).showProgressDialog();
            if (mAuth != null) {
                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "createUserWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference(Constants.TABLE_USER);
                                    ref.child(user.getUid()).setValue(new ReqRegisterModel(firstName, lastName, address, mobile, area, wordNo, email, aadharCard));
                                    Log.e(TAG, "" + user.getUid());
                                    Toast.makeText(getActivity(), "You have successfully register. Please login", Toast.LENGTH_SHORT).show();
                                    getFragmentManager().popBackStack();
                                } else {
                                    Log.w(TAG, "createUserWithEmail:failure" + task.getException());
                                    Toast.makeText(getActivity(), "" + task.getException().getMessage(),
                                            Toast.LENGTH_SHORT).show();
                                }
                                ((AuthorizationActivity) getActivity()).hideProgressDialog();
                            }
                        });
            }*/
        }
    }

    private class addData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @SuppressLint("WrongThread")
        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "registration");
            hashMap.put("fname", edtFirstName.getText().toString());
            hashMap.put("lname", edtLastName.getText().toString());
            hashMap.put("cNo", edtMobile.getText().toString());
            hashMap.put("email", edtEmail.getText().toString());
            hashMap.put("password", edtPassword.getText().toString());
            hashMap.put("address", edtAddress.getText().toString());
            hashMap.put("area", edtArea.getText().toString());
            hashMap.put("wordNo", edtWordNo.getText().toString());
            hashMap.put("adhar", edtAadharCard.getText().toString());
            hashMap.put("type", "User");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                    new SendMail(
                            requireActivity(),
                            edtEmail.getText().toString(),
                            "Registration Successful - Welcome to Meri Avaz!",
                            String.format("Dear %s %s,\n\nThank you for choosing Meri Avaz! We are excited to have you on board. Your registration is now complete, and you are all set to explore the features and benefits of our app.\n\nIf you have any queries or need assistance, feel free to reach out to us. Let your voice be heard!\n\nBest Regards,\nMeri Avaz Team", edtFirstName.getText().toString(), edtLastName.getText().toString())
                    )
                            .execute();
                    startActivity(new Intent(getActivity(), AuthorizationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

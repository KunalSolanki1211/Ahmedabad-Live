package com.meri.aavaz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.meri.aavaz.fragment.AdminComplaintListFragment;
import com.meri.aavaz.utils.ConstantSp;

import java.util.ArrayList;

public class AdminActivity extends AppCompatActivity {
    SharedPreferences sp;
    ArrayList<AdminDashboardModel> homeList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        sp = this.getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);
        final RecyclerView rvHome = findViewById(R.id.fragment_admin_dahsboard_rv);
        final GridLayoutManager gm = new GridLayoutManager(this, 1);
        rvHome.setLayoutManager(gm);
        homeList = new ArrayList<>();
        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {
            homeList.add(new AdminDashboardModel(0, getString(R.string.type), R.drawable.logo_departments));
            homeList.add(new AdminDashboardModel(1, getString(R.string.view_complaint), R.drawable.logo_complaints));
            homeList.add(new AdminDashboardModel(2, getString(R.string.logout), R.drawable.logo_logout));
        } else {
            homeList.add(new AdminDashboardModel(0, getString(R.string.view_complaint), R.drawable.logo_complaints));
            homeList.add(new AdminDashboardModel(1, getString(R.string.logout), R.drawable.logo_logout));
        }
//        homeList.add(new HomeModel(5, getString(R.string.government_departments)));
        final AdminDashboardAdapter homeAdapter = new AdminDashboardAdapter(homeList);
        homeAdapter.setOnItemClickListener(this::onItemClickListener);
        //homeAdapter.addAll(homeList);
        rvHome.setAdapter(homeAdapter);
    }

    private void onItemClickListener(int position) {
        if (sp.getString(ConstantSp.TYPE, "").equalsIgnoreCase("Admin")) {

            switch (position) {
                case 0:
                    startActivity(new Intent(this, DepartmentsListActivity.class));
                    break;
                case 1:
                    startActivity(new Intent(this, AdminComplainListActivity.class));
                    break;
                case 2:
                    sp.edit().clear().commit();
                    startActivity(new Intent(this, AuthorizationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;
            }
        } else {
            switch (position) {
                case 0:
                    startActivity(new Intent(this, AdminComplainListActivity.class));
                    break;
                case 1:
                    sp.edit().clear().commit();
                    startActivity(new Intent(this, AuthorizationActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
                    break;
            }
        }
    }
}
package com.meri.aavaz.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/*import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;*/

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

import com.meri.aavaz.HomeActivity;
import com.meri.aavaz.R;
import com.meri.aavaz.model.ReqRegisterModel;
import com.meri.aavaz.utils.ConnectionDetector;
import com.meri.aavaz.utils.ConstantSp;
import com.meri.aavaz.utils.MakeServiceCall;

/**
 * Created by mavyasoni on 25/02/18.
 */

public class ProfileFragment extends Fragment {

    private static final String TAG = ProfileFragment.class.getSimpleName();

    private EditText edtEmail;
    private EditText edtPassword;
    private EditText edtFirstName;
    private EditText edtLastName;
    private EditText edtAddress;
    private EditText edtMobile;
    private EditText edtArea;
    private EditText edtWordNo;
    private EditText edtAadharCardNo;
    SharedPreferences sp;

    //private FirebaseAuth mAuth;
    Button edit,btnSubmit;
    String firstName, lastName, address, mobile, area, wordNo, aadharCardNo, email, password;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ((HomeActivity) getActivity()).setTitle(getString(R.string.view_profile));
        sp = getActivity().getSharedPreferences(ConstantSp.PREF, Context.MODE_PRIVATE);

        edtEmail = view.findViewById(R.id.fragment_profile_edt_email);
        edtPassword = view.findViewById(R.id.fragment_profile_edt_password);
        edtFirstName = view.findViewById(R.id.fragment_profile_edt_first_name);
        edtLastName = view.findViewById(R.id.fragment_profile_edt_last_name);
        edtAddress = view.findViewById(R.id.fragment_profile_edt_address);
        edtMobile = view.findViewById(R.id.fragment_profile_edt_mobile);
        edtArea = view.findViewById(R.id.fragment_profile_edt_area);
        edtWordNo = view.findViewById(R.id.fragment_profile_edt_word_no);
        edtAadharCardNo = view.findViewById(R.id.fragment_profile_edt_aadhar_card_no);
        //edtPassword.setVisibility(View.GONE);
        //edtEmail.setVisibility(View.GONE);

        //mAuth = FirebaseAuth.getInstance();
        edit = view.findViewById(R.id.fragment_profile_btn_edit);
        btnSubmit = view.findViewById(R.id.fragment_profile_btn_submit);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //updateProfile(email);
                email = edtEmail.getText().toString().trim();
                firstName = edtFirstName.getText().toString().trim();
                lastName = edtLastName.getText().toString().trim();
                address = edtAddress.getText().toString().trim();
                mobile = edtMobile.getText().toString().trim();
                area = edtArea.getText().toString().trim();
                wordNo = edtWordNo.getText().toString().trim();
                aadharCardNo = edtAadharCardNo.getText().toString().trim();
                password = edtPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(firstName)) {
                    Toast.makeText(getActivity(), "Please enter a first name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(lastName)) {
                    Toast.makeText(getActivity(), "Please enter a last name", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getActivity(), "Please enter a password", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(address)) {
                    Toast.makeText(getActivity(), "Please enter a address", Toast.LENGTH_SHORT).show();
                } else if (mobile.length() < 10 || mobile.length() > 10) {
                    Toast.makeText(getActivity(), "Please enter valid mobile", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(area)) {
                    Toast.makeText(getActivity(), "Please enter a area", Toast.LENGTH_SHORT).show();
                } else if (TextUtils.isEmpty(wordNo)) {
                    Toast.makeText(getActivity(), "Please enter a wordNo", Toast.LENGTH_SHORT).show();
                } else if (aadharCardNo.length() > 12 || aadharCardNo.length() < 12) {
                    Toast.makeText(getActivity(), "Please enter valid Aadhar Card", Toast.LENGTH_SHORT).show();
                } else {
                    if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                        new updateData().execute();
                    } else {
                        new ConnectionDetector(getActivity()).connectiondetect();
                    }
                }
            }
        });

        if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
            new getData().execute();
        } else {
            new ConnectionDetector(getActivity()).connectiondetect();
        }

        final ReqRegisterModel reqRegisterModel = ((HomeActivity) getActivity()).getReqRegisterModel();
        if (reqRegisterModel != null) {
            edtEmail.setText(reqRegisterModel.getEmail());
            edtFirstName.setText(reqRegisterModel.getFirstName());
            edtLastName.setText(reqRegisterModel.getLastName());
            edtAddress.setText(reqRegisterModel.getAddress());
            edtMobile.setText(reqRegisterModel.getMobile());
            edtArea.setText(reqRegisterModel.getArea());
            edtWordNo.setText(reqRegisterModel.getWordNo());
            edtAadharCardNo.setText(reqRegisterModel.getAadharCardNo());
        }

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtEmail.setEnabled(true);
                edtPassword.setEnabled(true);
                edtFirstName.setEnabled(true);
                edtLastName.setEnabled(true);
                edtAddress.setEnabled(true);
                edtMobile.setEnabled(true);
                edtArea.setEnabled(true);
                edtWordNo.setEnabled(true);
                edtAadharCardNo.setEnabled(true);
                btnSubmit.setVisibility(View.VISIBLE);
                edit.setVisibility(View.GONE);
            }
        });

    }


    private void updateProfile(final String email) {
        Log.d(TAG, "createAccount:" + email);

        //FirebaseUser user = mAuth.getCurrentUser();
        final String firstName = edtFirstName.getText().toString().trim();
        final String lastName = edtLastName.getText().toString().trim();
        final String address = edtAddress.getText().toString().trim();
        final String mobile = edtMobile.getText().toString().trim();
        final String area = edtArea.getText().toString().trim();
        final String wordNo = edtWordNo.getText().toString().trim();
        final String aadharCardNo = edtAadharCardNo.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            Toast.makeText(getActivity(), "Please enter a email", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(firstName)) {
            Toast.makeText(getActivity(), "Please enter a first name", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(lastName)) {
            Toast.makeText(getActivity(), "Please enter a last name", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(address)) {
            Toast.makeText(getActivity(), "Please enter a address", Toast.LENGTH_SHORT).show();
        } else if (mobile.length() < 10 || mobile.length() > 10) {
            Toast.makeText(getActivity(), "Please enter valid mobile", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(area)) {
            Toast.makeText(getActivity(), "Please enter a area", Toast.LENGTH_SHORT).show();
        } else if (TextUtils.isEmpty(wordNo)) {
            Toast.makeText(getActivity(), "Please enter a wordNo", Toast.LENGTH_SHORT).show();
        } else if (aadharCardNo.length() > 12 || aadharCardNo.length() < 12) {
            Toast.makeText(getActivity(), "Please enter valid Aadhar Card", Toast.LENGTH_SHORT).show();
        } else {
            if (new ConnectionDetector(getActivity()).isConnectingToInternet()) {
                new updateData().execute();
            } else {
                new ConnectionDetector(getActivity()).connectiondetect();
            }
            /*((HomeActivity) getActivity()).showProgressDialog();
            DatabaseReference ref = FirebaseDatabase.getInstance().getReference(Constants.TABLE_USER);
            ref = ref.child(user.getUid());
            ref.setValue(new ReqRegisterModel(firstName, lastName, address, mobile, area, wordNo, email, aadharCardNo));
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (getActivity() != null && !getActivity().isFinishing() && isAdded()) {
                        Toast.makeText(getActivity(), "User updated successfully!", Toast.LENGTH_SHORT).show();
                        ((HomeActivity) getActivity()).hideProgressDialog();
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    if (getActivity() != null && !getActivity().isFinishing() && isAdded()) {
                        Toast.makeText(getActivity(), "" + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                        ((HomeActivity) getActivity()).hideProgressDialog();
                    }
                }
            });*/
        }

    }

    private class getData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "getProfile");
            hashMap.put("id", sp.getString(ConstantSp.ID, ""));
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    JSONArray array = object.getJSONArray("response");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject jsonObject = array.getJSONObject(i);
                        edtEmail.setText(jsonObject.getString("email"));
                        edtPassword.setText(jsonObject.getString("password"));
                        edtFirstName.setText(jsonObject.getString("fname"));
                        edtLastName.setText(jsonObject.getString("lname"));
                        edtAddress.setText(jsonObject.getString("address"));
                        edtMobile.setText(jsonObject.getString("cNo"));
                        edtArea.setText(jsonObject.getString("area"));
                        edtWordNo.setText(jsonObject.getString("wordNo"));
                        edtAadharCardNo.setText(jsonObject.getString("adhar"));
                    }
                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class updateData extends AsyncTask<String, String, String> {

        ProgressDialog pd;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            pd = new ProgressDialog(getActivity());
            pd.setMessage("Please Wait...");
            pd.setCancelable(false);
            pd.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            HashMap<String, String> hashMap = new HashMap<>();
            hashMap.put("action", "updateProfile");
            hashMap.put("id", sp.getString(ConstantSp.ID, ""));
            hashMap.put("fname", firstName);
            hashMap.put("lname", lastName);
            hashMap.put("cNo", mobile);
            hashMap.put("email", email);
            hashMap.put("password", password);
            hashMap.put("address", address);
            hashMap.put("area", area);
            hashMap.put("wordNo", wordNo);
            hashMap.put("adhar", aadharCardNo);
            hashMap.put("type", "User");
            return new MakeServiceCall().makeServiceCall(ConstantSp.BASE_URL + "user_management.php", MakeServiceCall.POST, hashMap);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            pd.dismiss();
            try {
                JSONObject object = new JSONObject(s);
                if (object.getString("Status").equalsIgnoreCase("True")) {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                    sp.edit().putString(ConstantSp.FNAME, firstName).commit();
                    sp.edit().putString(ConstantSp.LNAME, lastName).commit();
                    sp.edit().putString(ConstantSp.CNO, mobile).commit();
                    sp.edit().putString(ConstantSp.EMAIL, email).commit();
                    sp.edit().putString(ConstantSp.PASSWORD, password).commit();
                    sp.edit().putString(ConstantSp.ADDRESS, address).commit();
                    sp.edit().putString(ConstantSp.AREA, area).commit();
                    sp.edit().putString(ConstantSp.WORDNO, wordNo).commit();
                    sp.edit().putString(ConstantSp.ADHAR, aadharCardNo).commit();

                    edtEmail.setEnabled(false);
                    edtPassword.setEnabled(false);
                    edtFirstName.setEnabled(false);
                    edtLastName.setEnabled(false);
                    edtAddress.setEnabled(false);
                    edtMobile.setEnabled(false);
                    edtArea.setEnabled(false);
                    edtWordNo.setEnabled(false);
                    edtAadharCardNo.setEnabled(false);
                    btnSubmit.setVisibility(View.GONE);
                    edit.setVisibility(View.VISIBLE);

                } else {
                    Toast.makeText(getActivity(), object.getString("Message"), Toast.LENGTH_SHORT).show();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}

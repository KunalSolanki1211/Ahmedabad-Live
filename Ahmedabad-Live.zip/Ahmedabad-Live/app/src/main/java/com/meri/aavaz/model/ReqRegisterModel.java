package com.meri.aavaz.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by mavyasoni on 25/02/18.
 */

public class ReqRegisterModel implements Parcelable {

    private String firstName;
    private String lastName;
    private String address;
    private String area;
    private String wordNo;
    private String mobile;
    private String email;
    private String aadharCardNo;
    private int userType =0;


    public ReqRegisterModel() {
    }

    public ReqRegisterModel(String firstName, String lastName, String address, String area, String wordNo, String mobile
            , String email
            , String aadharCardNo) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.area = area;
        this.wordNo = wordNo;
        this.mobile = mobile;
        this.email = email;
        this.aadharCardNo = aadharCardNo;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getWordNo() {
        return wordNo;
    }

    public void setWordNo(String wordNo) {
        this.wordNo = wordNo;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    public String getAadharCardNo() {
        return aadharCardNo;
    }

    public void setAadharCardNo(String aadharCardNo) {
        this.aadharCardNo = aadharCardNo;
    }

    public int getUserType() {
        return userType;
    }

    public void setUserType(int userType) {
        this.userType = userType;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.firstName);
        dest.writeString(this.lastName);
        dest.writeString(this.address);
        dest.writeString(this.area);
        dest.writeString(this.wordNo);
        dest.writeString(this.mobile);
        dest.writeString(this.email);
        dest.writeString(this.aadharCardNo);
        dest.writeInt(this.userType);
    }

    protected ReqRegisterModel(Parcel in) {
        this.firstName = in.readString();
        this.lastName = in.readString();
        this.address = in.readString();
        this.area = in.readString();
        this.wordNo = in.readString();
        this.mobile = in.readString();
        this.email = in.readString();
        this.aadharCardNo = in.readString();
        this.userType = in.readInt();
    }

    public static final Creator<ReqRegisterModel> CREATOR = new Creator<ReqRegisterModel>() {
        @Override
        public ReqRegisterModel createFromParcel(Parcel source) {
            return new ReqRegisterModel(source);
        }

        @Override
        public ReqRegisterModel[] newArray(int size) {
            return new ReqRegisterModel[size];
        }
    };
}

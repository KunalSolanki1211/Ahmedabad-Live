package com.meri.aavaz.utils;

/**
 * Purpose :
 * Created by mavya.soni on 26/02/18.
 * Modified by mavya.soni on 26/02/18.
 */

public class Constants {

    public static final String TABLE_USER = "tb_user";
    public static final String TABLE_COMPLAINT = "tb_complaint";
    public static final String KEY_USER_DATA = "KEY_USER_DATA";
    public static final String FOLDER_DOCUMENTS = "documents/";
}

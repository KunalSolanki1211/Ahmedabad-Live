package com.meri.aavaz.model;

/**
 * Purpose :
 * Created by mavya.soni on 26/02/18.
 * Modified by mavya.soni on 26/02/18.
 */

public class HomeModel {

    private int id;
    private String title;
    private int image;

    public HomeModel(int id, String title, int image) {
        this.id = id;
        this.title = title;
        this.image = image;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
